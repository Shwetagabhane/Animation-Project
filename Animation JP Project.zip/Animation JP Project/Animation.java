//MOVING OF CARS
import java.awt.*;
import java.util.*;
import java.applet.*;
/*
 <applet code="Animation.class" width="500" height="500">
 </applet> 
*/
//The basic applet class.The applet shows 4 cars crossing each other at a square.
public class Animation extends Applet implements Runnable
{
	Thread t;
	Image Picture,p1,p2,p3;
	public void init()//Image insertion
	{
		Picture=getImage(getDocumentBase(),"g1.jpg");
		p1=getImage(getDocumentBase(),"g2.jpg");
		p2=getImage(getDocumentBase(),"g3.jpg");
		p3=getImage(getDocumentBase(),"g4.jpg");		
	}
	//4 variables used to vary the car's positions.
	int x1=0,x2=380,y1=50,y2=400;
	public void start()
	{
		if(t==null)
		{
			t=new Thread(this,"New Thread");
			t.start();
		}
	}
	public void stop()
	{
		if(t!=null)
		{
			t=null;
		}
	}	
	public void run()
	{
		Thread t1=Thread.currentThread();
		while(t==t1)
		{
			repaint();
			try
			{
				Thread.sleep(200);
			}
			catch(Exception e)
			{
				System.out.println("Exception is : "+e);  
			 }
		}
	}
	public void paint(Graphics g)
	{
		setBackground(Color.yellow);
		g.setColor(Color.BLACK);
		x1=(x1+17)%490;
		x2=x2-17;
		y1=(y1+20)%490;
		y2=y2-17;
		if(y2<0)
			y2=450;
		if(x2<0)
			x2=450;
		//Draw the roads using 2 filled rectangles using black color.
		g.fillRect(0,200,500,80);
		g.fillRect(200,0,80,500);
		//Draw the white colored lines.
		g.setColor(Color.white);
		for(int i=0;i<25;i++)
		{
	 		//if(i!=9 && i!=10)
				g.drawLine(i*20,233,i*20+10,233);
		}
		for(int j=0;j<17;j++)
		{
			//if(j!=7 && j!=8)
				g.drawLine(240,j*30,240,j*30+10);
		}
		//Draw 4 colored cars using filled round rectangles.
		g.setColor(Color.red);
		g.fillRoundRect(x2,243,30,10,2,2);
		g.setColor(Color.GREEN);
		g.fillRoundRect(x1,210,30,10,2,2);
		g.setColor(Color.BLUE);
		g.fillRoundRect(220,y1,10,30,2,2);
		g.setColor(Color.PINK);
		g.fillRoundRect(260,y2,10,30,2,2);
		//For grass Image
		g.drawImage(Picture,0,0,this);
		g.drawImage(p1,280,0,this);
		g.drawImage(p2,0,280,this);
		g.drawImage(p3,280,280,this);
	}
}